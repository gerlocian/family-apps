'use strict';
const AWS = require('aws-sdk');
const Lambda = new AWS.Lambda();

class InvokeParams {
    constructor(payload) {
        this.FunctionName = 'StepFunctionExecutionLambda';
        this.Payload = payload;
    }
}

module.exports.service = function(event, context, callback) {
    console.log(event);
};